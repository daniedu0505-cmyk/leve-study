-- Estudo Leve — Supabase schema + Row Level Security
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null default 'Estudante',
  role text not null default 'student' check (role in ('student','owner')),
  created_at timestamptz not null default now()
);

create table if not exists public.class_content (
  id integer primary key check (id = 1),
  data jsonb not null default '{"exams":[],"notices":[],"modules":[],"materials":[]}'::jsonb,
  updated_by uuid references auth.users(id),
  updated_at timestamptz not null default now()
);

create table if not exists public.student_progress (
  user_id uuid primary key references auth.users(id) on delete cascade,
  data jsonb not null default '{"completed":[],"scores":{},"notes":""}'::jsonb,
  updated_at timestamptz not null default now()
);

alter table public.profiles enable row level security;
alter table public.class_content enable row level security;
alter table public.student_progress enable row level security;

-- A própria pessoa lê/edita apenas o seu perfil, mas não altera o próprio papel.
drop policy if exists "profile read self" on public.profiles;
create policy "profile read self" on public.profiles for select to authenticated using (id = auth.uid());
drop policy if exists "profile update self name" on public.profiles;
create policy "profile update self name" on public.profiles for update to authenticated using (id = auth.uid()) with check (id = auth.uid() and role = 'student');

-- Conteúdo compartilhado: leitura para estudantes autenticados, escrita apenas owner.
drop policy if exists "class content read" on public.class_content;
create policy "class content read" on public.class_content for select to authenticated using (true);
drop policy if exists "class content owner insert" on public.class_content;
create policy "class content owner insert" on public.class_content for insert to authenticated with check (exists(select 1 from public.profiles p where p.id=auth.uid() and p.role='owner'));
drop policy if exists "class content owner update" on public.class_content;
create policy "class content owner update" on public.class_content for update to authenticated using (exists(select 1 from public.profiles p where p.id=auth.uid() and p.role='owner')) with check (exists(select 1 from public.profiles p where p.id=auth.uid() and p.role='owner'));

-- Progresso e anotações: cada estudante acessa somente a própria linha.
drop policy if exists "progress own select" on public.student_progress;
create policy "progress own select" on public.student_progress for select to authenticated using (user_id=auth.uid());
drop policy if exists "progress own insert" on public.student_progress;
create policy "progress own insert" on public.student_progress for insert to authenticated with check (user_id=auth.uid());
drop policy if exists "progress own update" on public.student_progress;
create policy "progress own update" on public.student_progress for update to authenticated using (user_id=auth.uid()) with check (user_id=auth.uid());

-- Criar perfil automaticamente após cadastro.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public
as $$
begin
  insert into public.profiles(id, display_name)
  values(new.id, coalesce(new.raw_user_meta_data->>'display_name', split_part(new.email,'@',1)));
  return new;
end;
$$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
for each row execute procedure public.handle_new_user();

insert into public.class_content(id,data)
values(1,'{"exams":[],"notices":[],"modules":[],"materials":[]}'::jsonb)
on conflict(id) do nothing;

-- IMPORTANTE: depois de criar sua conta e confirmar o e-mail, execute no SQL Editor:
-- update public.profiles set role='owner' where id=(select id from auth.users where email='SEU_EMAIL_DE_PROPRIETARIO');
-- Use o e-mail do proprietário e não compartilhe credenciais administrativas.
