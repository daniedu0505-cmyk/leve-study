# Estudo Leve — pacote inicial pronto para GitHub

Plataforma azul com:
- Cadastro e login de estudantes.
- Agenda compartilhada de provas e avisos.
- Trilha de estudos com resumo, link de videoaula, quiz e nota.
- Biblioteca de materiais.
- Painel de proprietário para publicar provas, avisos, módulos e materiais.
- Progresso e bloco de notas salvos individualmente na nuvem.
- Tutor IA com Gemini por função de servidor (a chave não fica no navegador).

## Arquivos
- `index.html`: interface da plataforma.
- `supabase/schema.sql`: tabelas e regras de segurança (RLS).
- `supabase/functions/tutor/index.ts`: função segura que chama o Gemini.

## 1. Criar o projeto Supabase
1. Acesse https://supabase.com e crie um projeto (ex.: `Missao803`).
2. Em **Project Settings → API**, copie a Project URL e a chave pública `anon`/`publishable`.
3. Abra `index.html` e substitua:
   - `COLE_AQUI_A_URL_DO_PROJETO_SUPABASE`
   - `COLE_AQUI_A_CHAVE_PUBLISHABLE_OU_ANON`
4. No Supabase, abra **SQL Editor → New query**, cole todo o conteúdo de `supabase/schema.sql` e execute.

## 2. Tornar sua conta a proprietária
1. Crie sua conta no Estudo Leve usando o e-mail de proprietário.
2. Confirme o e-mail, se a confirmação estiver habilitada, e entre.
3. No Supabase, abra **SQL Editor** e execute esta instrução substituindo pelo seu e-mail:
   ```sql
   update public.profiles
   set role = 'owner'
   where id = (select id from auth.users where email = 'SEU_EMAIL');
   ```
4. Saia e entre novamente. A aba Proprietário aparecerá somente para essa conta.

## 3. Ativar o Gemini (chave protegida)
1. Gere uma chave no Google AI Studio: https://aistudio.google.com/app/apikey
2. Instale a CLI do Supabase em um computador, entre na sua conta e vincule o projeto.
3. No terminal, dentro desta pasta, configure o segredo:
   ```bash
   supabase secrets set GEMINI_API_KEY=SUA_CHAVE_GEMINI
   supabase functions deploy tutor
   ```
A chave Gemini fica no servidor, nunca no HTML. Não publique sua chave em repositório GitHub.

## 4. Publicar no GitHub Pages
1. Crie um repositório chamado `estudo-leve`.
2. Envie `index.html` para a raiz do repositório.
3. Envie também a pasta `supabase` (ela guarda SQL e função; a hospedagem estática não a executa).
4. No GitHub: **Settings → Pages → Deploy from a branch → main → /(root) → Save**.
5. Aguarde a publicação e abra o endereço mostrado pelo GitHub Pages.

## Observações importantes
- GitHub Pages hospeda somente a interface estática. Supabase fornece login, banco, segurança e salvamento na nuvem.
- O painel não usa senha fixa no JavaScript. A permissão é validada pelo banco via RLS.
- Não use `service_role` ou chave secreta do Supabase no navegador.
- O armazenamento individual é separado pelo ID autenticado do usuário.
- Este é o pacote inicial funcional; adicione os conteúdos reais da sua turma pelo painel Proprietário após concluir a configuração.
