// Supabase Edge Function: tutor
// Configure secrets: GEMINI_API_KEY
// Deploy: supabase functions deploy tutor
import { serve } from "https://deno.land/std@0.224.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};
serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  if (req.method !== "POST") return new Response("Method not allowed", { status: 405, headers: cors });
  try {
    const auth = req.headers.get("Authorization");
    if (!auth) return new Response(JSON.stringify({ error: "Não autenticado" }), { status: 401, headers: {...cors,"Content-Type":"application/json"} });
    const supabase = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_ANON_KEY")!, { global: { headers: { Authorization: auth } } });
    const { data: { user }, error: userError } = await supabase.auth.getUser();
    if (userError || !user) return new Response(JSON.stringify({ error: "Sessão inválida" }), { status: 401, headers: {...cors,"Content-Type":"application/json"} });
    const { message, context } = await req.json();
    if (typeof message !== "string" || !message.trim() || message.length > 6000) return new Response(JSON.stringify({ error: "Mensagem inválida" }), { status: 400, headers: {...cors,"Content-Type":"application/json"} });
    const key = Deno.env.get("GEMINI_API_KEY");
    if (!key) throw new Error("GEMINI_API_KEY não configurada no servidor");
    const prompt = `Você é o Tutor Leve IA, um tutor educacional acolhedor e rigoroso. Responda em português brasileiro, explique passo a passo quando útil, não invente conteúdo do material da turma e sinalize incertezas. Contexto da turma: ${JSON.stringify(context ?? {})}\n\nPergunta do estudante: ${message}`;
    const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${key}`, {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ contents: [{ parts: [{ text: prompt }] }], generationConfig: { temperature: 0.5, maxOutputTokens: 1200 } })
    });
    const result = await response.json();
    if (!response.ok) throw new Error(result?.error?.message ?? "Falha na API Gemini");
    const reply = result?.candidates?.[0]?.content?.parts?.map((p: {text?:string})=>p.text ?? "").join("\n") ?? "Não consegui gerar uma resposta.";
    return new Response(JSON.stringify({ reply }), { headers: {...cors, "Content-Type":"application/json"} });
  } catch (error) {
    return new Response(JSON.stringify({ error: error instanceof Error ? error.message : "Erro interno" }), { status: 500, headers: {...cors, "Content-Type":"application/json"} });
  }
});
